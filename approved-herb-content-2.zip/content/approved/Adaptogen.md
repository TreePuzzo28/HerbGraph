---
type: action
title: Adaptogen
---
