---
type: action
title: Analgesic
---
