---
type: action
title: Antidiarrheal
---
