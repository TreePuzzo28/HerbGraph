---
type: action
title: Antihidrotic
---
