---
type: action
title: Antirheumatic
---
