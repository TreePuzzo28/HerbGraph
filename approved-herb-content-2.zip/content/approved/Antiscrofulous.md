---
type: action
title: Antiscrofulous
---
