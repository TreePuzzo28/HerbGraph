---
type: action
title: Antispasmodic
---
