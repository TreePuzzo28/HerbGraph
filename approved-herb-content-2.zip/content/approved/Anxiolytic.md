---
type: action
title: Anxiolytic
---
