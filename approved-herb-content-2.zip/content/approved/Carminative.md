---
type: action
title: Carminative
---
