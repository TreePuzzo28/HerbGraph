---
type: action
title: Diaphoretic
---
