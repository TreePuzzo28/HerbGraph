---
type: action
title: Diuretic
---
