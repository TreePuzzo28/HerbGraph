---
type: action
title: Emollient
---
