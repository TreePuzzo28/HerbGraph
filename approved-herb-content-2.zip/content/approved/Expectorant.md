---
type: action
title: Expectorant
---
