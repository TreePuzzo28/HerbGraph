---
type: action
title: Febrifuge
---
