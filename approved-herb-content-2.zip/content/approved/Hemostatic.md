---
type: action
title: Hemostatic
---
