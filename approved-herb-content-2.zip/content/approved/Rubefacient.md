---
type: action
title: Rubefacient
---
