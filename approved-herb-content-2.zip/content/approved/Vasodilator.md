---
type: action
title: Vasodilator
---
